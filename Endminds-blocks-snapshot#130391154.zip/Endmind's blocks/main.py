import sqlite3
from sqlite3 import Error
from direct.showbase.ShowBase import ShowBase
from direct.gui.OnscreenText import OnscreenText
from direct.gui.OnscreenImage import OnscreenImage
from panda3d.core import TransparencyAttrib, CollisionTraverser, CollisionHandlerQueue
from panda3d.core import loadPrcFileData, CollisionNode, CollisionSphere, BitMask32
from direct.gui.OnscreenText import TextNode
from direct.gui.OnscreenText import TextFont
from mapmanager import MapManager
from controller import Controller
from editor import Editor
from time import *
from PyQt5 import *
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QWidget,QPushButton,QLabel,QVBoxLayout,QHBoxLayout,QMessageBox, QGroupBox,QButtonGroup,QTextEdit,QLineEdit,QListWidget, QInputDialog
import sys, threading, pygame
pygame.init()
nicks = ['Endmind','nardi']
passwords = ['1298CCewrqrtwfdxtyqCwgu5316576Endmind','1234CCewrqrtwfdxtyqCwgu5316576nardi']
keys = ['25729759298644682','257297592CAPYBAR2023FOREVER','257297592FrrreeeeeeLIceNse','257297592#ESFOREVER!!1!!1!!1367']
correct = False
con = sqlite3.connect('playersxyz.db')
cur = con.cursor()
windowload = pygame.display.set_mode((1200,628))
pygame.display.set_caption("Loading Endmind's blocks...")
background = pygame.transform.scale(pygame.image.load('Endmind-Studios.jpg'), (1200,628))
CLOCK = pygame.time.Clock()
go_to = 180
windowload.blit(background, (0,0))
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    color = (204, 0, 0)

    pygame.draw.rect(windowload, color, pygame.Rect(go_to, 350, 60, 100))
    if go_to < 1020:
        go_to += 70
    else:
        break
    pygame.display.update()
    CLOCK.tick(10)
pygame.quit()
app = QApplication([])
window = QWidget()
window.setWindowTitle("Endmind's blocks launcher")
l_text = QLabel()
l_text.setText("Лаунчер Endmind's blocks")
username_field = QLineEdit()
username_field.setPlaceholderText('Имя пользователя')
password_field = QLineEdit()
password_field.setPlaceholderText('Пароль')
enter_btn = QPushButton()
enter_btn.setText('Войти')
wrong_text = QLabel()
wrong_text.setText('Введите имя пользователя и пароль')
password_field.setEchoMode(QLineEdit.Password)
creators_text =QLabel()
creators_text.setText('Создатели: Endmind, nardi (nspon)')
reg_btn = QPushButton()
reg_btn.setText('Зарегистрироваться(на один раз, аккаунт не сохраняется, нужен лицензионный ключ)')
key_field = QLineEdit()
key_field.setPlaceholderText('Ключ')
key_field.setEchoMode(QLineEdit.Password)
def check_password():
    nick = username_field.text()
    password = password_field.text()+'CCewrqrtwfdxtyqCwgu5316576'+username_field.text()
    if nick in nicks and password in passwords:
        wrong_text.setText('Вход как: '+nick+'. Загрузка...')
        global correct
        correct = True
        app.exit()
        windowload = pygame.display.set_mode((1200,628))
        pygame.display.set_caption("Loading Endmind's blocks...")
        background = pygame.transform.scale(pygame.image.load("Endmind's-blocks.jpg"), (1200,628))
        CLOCK = pygame.time.Clock()
        go_to = 180
        windowload.blit(background, (0,0))
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            color = (204, 0, 0)

            pygame.draw.rect(windowload, color, pygame.Rect(go_to, 528, 60, 100))
            if go_to < 1020:
                go_to += 70
            else:
                break
            pygame.display.update()
            CLOCK.tick(7)
        pygame.quit()
    else:
        wrong_text.setText('Неправильное имя пользователя или пароль')
def check_key():
    key = key_field.text()
    if '257297592'+key in keys:
        global nick
        nicks.append('Player')
        passwords.append('1234CCewrqrtwfdxtyqCwgu5316576Player')
        wrong_text.setText('Зарегестрировано! Ник: Player; Пароль: 1234;')
    else:
        wrong_text.setText('Такого ключа нет')
vline = QVBoxLayout()
vline.addWidget(l_text,alignment = Qt.AlignCenter)
vline.addWidget(wrong_text,alignment = Qt.AlignCenter)
vline.addWidget(username_field)
vline.addWidget(password_field)
vline.addWidget(enter_btn)
vline.addWidget(creators_text,alignment = Qt.AlignCenter)
vline.addWidget(reg_btn)
vline.addWidget(key_field)
window.setLayout(vline)
enter_btn.clicked.connect(check_password)
reg_btn.clicked.connect(check_key)
nick = username_field.text()
window.show() 
app.exec()
while True:
    if correct == True:
        break
nick = username_field.text()
print(nick)
#cur.execute('''CREATE TABLE IF NOT EXISTS xyz (playerName,x,y,z)''')
cur.execute("insert into xyz (playerName) values (?)", [nick])
con.commit()
#for row in cur.execute('''SELECT * FROM eee'''):
#    print(row)
#return connection
# Настройка конфигурации приложения
# Заголовок окна
loadPrcFileData('', "window-title Endmind's blocks")
# Отключение синхронизации
loadPrcFileData('', 'sync-video false')
# Включение отображения FPS
loadPrcFileData('', 'show-frame-rate-meter true')
# скрыть курсор мыши
loadPrcFileData('', 'cursor-hidden true')
# Установка размера окна
#loadPrcFileData('', 'win-size 1000 750')
loadPrcFileData('', 'win-size 1950 1100')
class Game(ShowBase):

    def __init__(self):
        ShowBase.__init__(self)

        skybox = loader.loadModel('skybox.egg')
        skybox.setScale(60)
        skybox.reparentTo(render)
        # режим редактирования
        self.edit_mode = True

        # создаём менеджер карты
        self.map_manager = MapManager()

        # создаём контроллер мышки и клавиатуры
        self.controller = Controller()

        # создаём редактор
        self.editor = Editor(self.map_manager)

        # загружаем картинку курсора
        self.pointer = OnscreenImage(image='target.png',
                                     pos=(0, 0, 0), scale=0.08)
        # устанавливаем прозрачность
        self.pointer.setTransparency(TransparencyAttrib.MAlpha)

        # имя файла для сохранения и загрузки карт
        self.file_name = "my_map.dat"
        self.file_name1 = 'my_map copy.dat'
        self.file_name2 = 'my_map copy 2.dat'
        self.file_name3 = 'my_map copy 3.dat'
        self.file_name4 = 'my_map copy 4.dat'
        self.file_name5 = "my_map.dat"
        self.accept("f1", self.basicMap)
        self.accept("f2", self.generateRandomMap)
        self.accept("f3", self.saveMap)
        self.accept("f4", self.loadMap)
        self.accept("f5", self.setMapTo1)
        self.accept("f6", self.setMapTo2)
        self.accept("f7", self.setMapTo3)
        self.accept("f8", self.setMapTo4)
        self.accept("f9", self.setMapTo5)
        self.accept("t", self.tp)
        '''self.accept("lshift", self.changeSphereB)
        self.accept("rshift", self.changeSphereS)'''
        self.accept("j", self.addJump)
        self.accept("f", self.addFly)

        

        print("'f1' - создать базовую карту")
        print("'f2' - создать случайную карту")
        print("'f3' - сохранить карту")
        print("'f4' - загрузить карту")
        
        self.accept("1", self.setColor, [(1,1,1,1)])
        self.accept("2", self.setColor, [(1,0.3,0.3,1)])
        self.accept("3", self.setColor, [(0.3,1,0.3,1)])
        self.accept("4", self.setColor, [(0.3,0.3,1,1)])
        self.accept("5", self.setColor, [(1,1,0.3,0.5)])
        self.accept("6", self.setColor, [(0.3,1,1,0.25)])
        self.accept("7", self.setColor, [(1,0.3,1,0.5)])
        self.accept("8", self.setColor, [None])
        # зарегистрируйте метод переключения режима
        # как функцию обработки события нажатия на клавишу "tab"
        base.accept('tab',self.switchEditMode)

        # генерируем случайный уровень
        self.basicMap()
    
        
    #cur.execute("insert into xyz (playerName) values (?)", [nick])
    #con.commit()
    def basicMap(self):
        if not self.edit_mode:
            self.controller.setEditMode(self.edit_mode)
        self.map_manager.basicMap()
        print('Basic map generated')

    def generateRandomMap(self):
        if not self.edit_mode:
            self.controller.setEditMode(self.edit_mode)
        self.map_manager.generateRandomMap()
        print('Random map generated')

    def saveMap(self):
        self.map_manager.saveMap(self.file_name)
        print('Map saved to "'+self.file_name+'"')

    def loadMap(self):
        base.camera.setZ(20)
        if not self.edit_mode:
            self.controller.setEditMode(self.edit_mode)
        self.map_manager.loadMap(self.file_name)
        print('Map loaded from "'+self.file_name+'"')
    def tp(self):
        base.camera.setZ(20)
        base.camera.setX(0)
        base.camera.setY(0)
    def changeSphereB(self):
        self.controller.changeSphereB()
    def changeSphereS(self):
        self.controller.changeSphereS()
    def addJump(self):
        self.controller.addJump()
    def addFly(self):
        self.controller.addFly()
    global nowX
    print(Controller.nowX)
    # Метод переключения режима редактирования
    def switchEditMode(self):
        self.edit_mode = not self.edit_mode
        self.controller.setEditMode(self.edit_mode)
        self.editor.setEditMode(self.edit_mode)

        if self.edit_mode:
            self.pointer.setImage(image='target.png')
        else:
            self.pointer.setImage(image='target1.png')
        self.pointer.setTransparency(TransparencyAttrib.MAlpha)
    def setColor(self,color):
        if self.edit_mode:
            self.map_manager.setColor(color)
    def setMapTo1(self):
        self.file_name = self.file_name5
        print('Saving to 1')
    def setMapTo2(self):
        self.file_name = self.file_name1
        print('Saving to 2')
    def setMapTo3(self):
        self.file_name = self.file_name2
        print('Saving to 3')
    def setMapTo4(self):
        self.file_name = self.file_name3
        print('Saving to 4')
    def setMapTo5(self):
        self.file_name = self.file_name4
        print('Saving to 5')
app = Game()
if correct:
    app.run()
